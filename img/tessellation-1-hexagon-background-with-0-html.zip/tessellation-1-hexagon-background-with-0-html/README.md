# Tessellation #1 (Hexagon background with 0 HTML)

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/mdmwgzx](https://codepen.io/t_afif/pen/mdmwgzx).

